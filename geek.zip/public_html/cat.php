<?php require_once './php/includes/config.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $config['title']; ?></title>
  <link rel="stylesheet" href="/styles/index.css">
  <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
	<script src="/js/scrollUp.js"></script>
	<script src="/js/jquery-3.3.1.min.js"></script>
	<script async src="//www.instagram.com/embed.js"></script>
</head>
<body>
  <?php  require_once './php/includes/menu.php';
    if (isset($_GET['cat_id'])) {
      $cat_id = $_GET['cat_id'];

      $sql_find_news = "SELECT  article_id,
                                title,
                                category_id,
                                views,
                                published,
                                article_img FROM articles WHERE category_id = '$cat_id'";
      $news = mysqli_query($link, $sql_find_news);

      if (!$news) {
        exit("Нет статей");
      } ?>
      
      <div class="news-flex">
      <?php
      
      while ($art = mysqli_fetch_assoc($news)) { 
      
      ?>
      
        <div class="flex-cells"><img src="<?php echo $art['article_img']; ?>" alt="">
          <a href="/cat.php?cat_id=<?php echo $all_categs[$cat_id-1]['category_id']; ?>" class="flex-caption  news-category">
            <?php echo $all_categs[$cat_id-1]['cat_name']; ?></a>
          <a href="/news.php?article_id=<?php echo $art['article_id']; ?>">
              <?php echo $art['title']; ?></a>
        </div>
      <?php
      }
      ?>
      </div>
    <?php
    }
    require_once './php/includes/footer.php';
  ?>
</body>
</html>