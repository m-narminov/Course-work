$('a.flipper').click(function(){
  $('.flip').toggleClass('flipped');
});