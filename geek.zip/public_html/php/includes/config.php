<?php
  $config = array(
    'title' => 'Geekin.tk',
    'db' => array(
      'server' => 'localhost',
      'username' => 'id8635757_root',
      'password' => 'aEhrTmcd2uAkKsM',
      'name' => 'id8635757_geekin'
    )
  );
 

  $link = mysqli_connect('localhost','id8635757_root','aEhrTmcd2uAkKsM', 'id8635757_geekin');
  mysqli_set_charset($link, "utf8");

  $sgv_path = '/res/img/svg/';
  $categories = array($sgv_path.'last.svg',
                      $sgv_path.'games.svg',
                      $sgv_path.'movies.svg',
                      $sgv_path.'comix.svg',
                      $sgv_path.'tech.svg',
                      $sgv_path.'sport.svg');

  //запрос списка категорий
  $sql_cat = "SELECT * FROM categories WHERE category_id <> 5 and category_id <> 6";
  $sql_all_cat = "SELECT * FROM categories";
  $all_cats = mysqli_query($link, $sql_all_cat);
  $all_categs = array();
  while ($cat_tmp = mysqli_fetch_assoc($all_cats)) {
    $all_categs[$cat_tmp['category_id']] = $cat_tmp['cat_name'];
  }
  
  $cat_stat = mysqli_query($link, $sql_cat);
?>