<footer>
	<div>
		<ul>
			<li><a href="">Контакты</a></li>
			<li><a href="">Рекламодателям</a></li>
			<li><a href="/rules.php">Правила сообщества</a></li>
		</ul>
	</div>
	<div class="info">© 2019 GeekNews</div>
</footer>
